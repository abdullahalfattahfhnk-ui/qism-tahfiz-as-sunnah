-- =====================================================================
-- RLS smoke test. Run in the Supabase SQL editor AFTER the 3 migrations.
-- It creates temporary fake users and data, checks who can see/do what,
-- then ROLLS BACK so nothing is kept. If every check passes, the last
-- result row says "all RLS checks passed". Any failure shows a message
-- starting with FAIL.
-- NOTE: written without being executed against a live database. If it errors
-- for a reason unrelated to a FAIL message, send me the error text.
-- =====================================================================
begin;

-- Fixtures (run as the SQL editor's privileged role) -------------------
insert into auth.users (id, aud, role, email) values
  ('00000000-0000-0000-0000-0000000000a1', 'authenticated', 'authenticated', 'admin@test.local'),
  ('00000000-0000-0000-0000-0000000000b1', 'authenticated', 'authenticated', 'teacher@test.local'),
  ('00000000-0000-0000-0000-0000000000c1', 'authenticated', 'authenticated', 'student1@test.local'),
  ('00000000-0000-0000-0000-0000000000c2', 'authenticated', 'authenticated', 'student2@test.local');

update public.profiles set role = 'super_admin' where id = '00000000-0000-0000-0000-0000000000a1';
update public.profiles set role = 'teacher'     where id = '00000000-0000-0000-0000-0000000000b1';

insert into public.departments (id, code, name_en)
values ('00000000-0000-0000-0000-0000000000d1', 'test-dept', 'Test department');

insert into public.classes (id, department_id, name_en) values
  ('00000000-0000-0000-0000-0000000000e1', '00000000-0000-0000-0000-0000000000d1', 'Class A'),
  ('00000000-0000-0000-0000-0000000000e2', '00000000-0000-0000-0000-0000000000d1', 'Class B');

insert into public.class_members (class_id, profile_id, member_role) values
  ('00000000-0000-0000-0000-0000000000e1', '00000000-0000-0000-0000-0000000000b1', 'teacher'),
  ('00000000-0000-0000-0000-0000000000e1', '00000000-0000-0000-0000-0000000000c1', 'student'),
  ('00000000-0000-0000-0000-0000000000e2', '00000000-0000-0000-0000-0000000000c2', 'student');

insert into public.announcements (id, class_id, title, body, created_by) values
  ('00000000-0000-0000-0000-0000000000f1', '00000000-0000-0000-0000-0000000000e1',
   'Class A news', 'x', '00000000-0000-0000-0000-0000000000b1');

insert into public.assignments (id, class_id, title, is_published, created_by) values
  ('00000000-0000-0000-0000-000000000a01', '00000000-0000-0000-0000-0000000000e1',
   'Published homework', true, '00000000-0000-0000-0000-0000000000b1'),
  ('00000000-0000-0000-0000-000000000a02', '00000000-0000-0000-0000-0000000000e1',
   'Draft homework', false, '00000000-0000-0000-0000-0000000000b1');

-- Helper: act as a given user (resets to the privileged role first) -----
create or replace function pg_temp.act_as(uid uuid) returns void
language plpgsql as $$
begin
  reset role;
  perform set_config('request.jwt.claims',
    json_build_object('sub', uid, 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

-- 1. Student 1 sees Class A's announcement; student 2 (other class) does not
reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000c1');
do $$ begin
  assert (select count(*) from public.announcements) = 1, 'FAIL: student1 should see 1 announcement';
end $$;
reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000c2');
do $$ begin
  assert (select count(*) from public.announcements) = 0, 'FAIL: student2 must not see Class A announcements';
end $$;

-- 2. Students see published assignments only, and only in their class
reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000c1');
do $$ begin
  assert (select count(*) from public.assignments) = 1, 'FAIL: student1 should see only the published assignment';
end $$;
reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000b1');
do $$ begin
  assert (select count(*) from public.assignments) = 2, 'FAIL: teacher should see published and draft';
end $$;
reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000c2');
do $$ begin
  assert (select count(*) from public.assignments) = 0, 'FAIL: student2 must not see Class A assignments';
end $$;

-- 3. A student cannot promote themselves
reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000c1');
do $$ begin
  begin
    update public.profiles set role = 'super_admin'
      where id = '00000000-0000-0000-0000-0000000000c1';
    raise exception 'FAIL: student changed own role';
  exception when insufficient_privilege then null;
  end;
end $$;

-- 4. A student cannot post announcements
do $$ begin
  begin
    insert into public.announcements (class_id, title, body, created_by)
    values ('00000000-0000-0000-0000-0000000000e1', 'Hack', 'x',
            '00000000-0000-0000-0000-0000000000c1');
    raise exception 'FAIL: student posted an announcement';
  exception when insufficient_privilege then null;
  end;
end $$;

-- 5. Submissions: student1 may submit; student2 may not; nobody can forge another student
do $$ begin
  insert into public.submissions (assignment_id, student_id, content)
  values ('00000000-0000-0000-0000-000000000a01',
          '00000000-0000-0000-0000-0000000000c1', 'my answer');
  begin
    insert into public.submissions (assignment_id, student_id, content)
    values ('00000000-0000-0000-0000-000000000a01',
            '00000000-0000-0000-0000-0000000000c2', 'forged');
    raise exception 'FAIL: student1 submitted as student2';
  exception when insufficient_privilege then null;
  end;
  begin
    insert into public.submissions (assignment_id, student_id, content)
    values ('00000000-0000-0000-0000-000000000a02',
            '00000000-0000-0000-0000-0000000000c1', 'draft assignment');
    raise exception 'FAIL: student submitted to an unpublished assignment';
  exception when insufficient_privilege then null;
  end;
end $$;

reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000c2');
do $$ begin
  begin
    insert into public.submissions (assignment_id, student_id, content)
    values ('00000000-0000-0000-0000-000000000a01',
            '00000000-0000-0000-0000-0000000000c2', 'outsider');
    raise exception 'FAIL: student from another class submitted';
  exception when insufficient_privilege then null;
  end;
  assert (select count(*) from public.submissions) = 0, 'FAIL: student2 sees others submissions';
end $$;

-- 6. The teacher sees the submission
reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000b1');
do $$ begin
  assert (select count(*) from public.submissions) = 1, 'FAIL: teacher should see the submission';
end $$;

-- 7. Profile privacy
reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000c2');
do $$ begin
  assert (select count(*) from public.profiles
          where id = '00000000-0000-0000-0000-0000000000c1') = 0,
    'FAIL: student2 can see student1 profile';
end $$;
reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000c1');
do $$ begin
  assert (select count(*) from public.profiles
          where id = '00000000-0000-0000-0000-0000000000b1') = 1,
    'FAIL: student1 should see their teacher';
  assert (select count(*) from public.profiles
          where id = '00000000-0000-0000-0000-0000000000c2') = 0,
    'FAIL: student1 can see a student from another class';
end $$;

-- 8. Super admin sees everything
reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000a1');
do $$ begin
  assert (select count(*) from public.profiles) >= 4, 'FAIL: admin should see all profiles';
end $$;

-- 9. Not signed in: no access at all
reset role;
set local role anon;
do $$ begin
  begin
    perform count(*) from public.profiles;
    raise exception 'FAIL: anonymous visitor could query profiles';
  exception when insufficient_privilege then null;
  end;
end $$;

reset role;
select 'all RLS checks passed' as result;
rollback;
