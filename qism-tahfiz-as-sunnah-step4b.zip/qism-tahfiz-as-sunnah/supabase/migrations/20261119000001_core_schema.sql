-- =====================================================================
-- قسم تحفيظ السنة (Qism Tahfiz as-Sunnah)
-- Migration 1 of 3: core schema (types, tables, indexes, triggers)
-- Run order: 1 schema -> 2 rls -> 3 storage
-- =====================================================================

-- ---------- Types ----------
create type public.user_role as enum ('super_admin', 'teacher', 'student');
create type public.resource_type as enum ('book', 'notes', 'audio', 'worksheet');
create type public.announcement_category as enum ('general', 'academic', 'event');

-- ---------- Shared trigger: keep updated_at current ----------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ---------- Structure: departments, classes ----------
create table public.departments (
  id          uuid primary key default gen_random_uuid(),
  code        text not null unique,
  name_ar     text,
  name_bn     text,
  name_en     text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  constraint departments_has_name check (coalesce(name_ar, name_bn, name_en) is not null)
);

create table public.classes (
  id            uuid primary key default gen_random_uuid(),
  department_id uuid not null references public.departments (id) on delete restrict,
  name_ar       text,
  name_bn       text,
  name_en       text,
  academic_year text,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  constraint classes_has_name check (coalesce(name_ar, name_bn, name_en) is not null)
);
create index classes_department_idx on public.classes (department_id);

-- ---------- People ----------
-- One row per auth user. Email and password live in auth.users only.
create table public.profiles (
  id               uuid primary key references auth.users (id) on delete cascade,
  full_name        text not null check (length(trim(full_name)) > 0),
  role             public.user_role not null default 'student',
  student_code     text unique,
  preferred_locale text not null default 'bn' check (preferred_locale in ('bn', 'ar', 'en')),
  avatar_path      text,
  is_active        boolean not null default true,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

-- Who belongs to which class, and in what capacity.
-- Teachers can belong to many classes; students normally to one.
create table public.class_members (
  class_id    uuid not null references public.classes (id) on delete cascade,
  profile_id  uuid not null references public.profiles (id) on delete cascade,
  member_role public.user_role not null check (member_role in ('teacher', 'student')),
  created_at  timestamptz not null default now(),
  primary key (class_id, profile_id)
);
create index class_members_profile_idx on public.class_members (profile_id);

-- ---------- Academic content ----------
create table public.subjects (
  id            uuid primary key default gen_random_uuid(),
  department_id uuid not null references public.departments (id) on delete restrict,
  code          text not null,
  name_ar       text,
  name_bn       text,
  name_en       text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (department_id, code),
  constraint subjects_has_name check (coalesce(name_ar, name_bn, name_en) is not null)
);

create table public.books (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid not null references public.classes (id) on delete restrict,
  subject_id   uuid references public.subjects (id) on delete set null,
  title        text not null,
  author       text,
  description  text,
  is_published boolean not null default false,
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index books_class_idx on public.books (class_id, subject_id);

create table public.lessons (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid not null references public.classes (id) on delete restrict,
  subject_id   uuid references public.subjects (id) on delete set null,
  book_id      uuid references public.books (id) on delete set null,
  title        text not null,
  summary      text,
  position     integer not null default 0,
  is_published boolean not null default false,
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index lessons_class_idx on public.lessons (class_id, subject_id, position);

-- A file in Storage (bucket "resources"), described by a row here.
create table public.resources (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid not null references public.classes (id) on delete restrict,
  subject_id   uuid references public.subjects (id) on delete set null,
  lesson_id    uuid references public.lessons (id) on delete set null,
  book_id      uuid references public.books (id) on delete set null,
  type         public.resource_type not null,
  title        text not null,
  description  text,
  storage_path text not null unique,   -- "<class_id>/<file>" inside bucket "resources"
  file_name    text,
  mime_type    text,
  size_bytes   bigint check (size_bytes >= 0),
  is_published boolean not null default false,
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index resources_class_idx on public.resources (class_id, subject_id);

-- ---------- Communication ----------
-- class_id null = madrasa-wide announcement (super admin only).
create table public.announcements (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid references public.classes (id) on delete restrict,
  category     public.announcement_category not null default 'general',
  title        text not null,
  body         text not null,
  is_pinned    boolean not null default false,
  is_published boolean not null default true,
  published_at timestamptz not null default now(),
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index announcements_class_idx on public.announcements (class_id, published_at desc);

-- ---------- Assignments ----------
create table public.assignments (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid not null references public.classes (id) on delete restrict,
  subject_id   uuid references public.subjects (id) on delete set null,
  title        text not null,
  description  text,
  due_at       timestamptz,
  is_published boolean not null default false,
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index assignments_class_idx on public.assignments (class_id, due_at);

-- One submission per student per assignment. Grades come later (exams/results).
create table public.submissions (
  id            uuid primary key default gen_random_uuid(),
  assignment_id uuid not null references public.assignments (id) on delete cascade,
  student_id    uuid not null references public.profiles (id) on delete cascade,
  content       text,
  file_path     text,   -- "<assignment_id>/<student_id>/<file>" inside bucket "submissions"
  submitted_at  timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (assignment_id, student_id),
  constraint submissions_has_content check (content is not null or file_path is not null)
);
create index submissions_student_idx on public.submissions (student_id);

-- ---------- Timetable ----------
create table public.class_schedules (
  id         uuid primary key default gen_random_uuid(),
  class_id   uuid not null references public.classes (id) on delete restrict,
  subject_id uuid references public.subjects (id) on delete set null,
  teacher_id uuid references public.profiles (id) on delete set null,
  weekday    smallint not null check (weekday between 0 and 6),  -- 0 = Sunday ... 6 = Saturday
  start_time time not null,
  end_time   time not null,
  room       text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint class_schedules_time_order check (end_time > start_time)
);
create index class_schedules_class_idx on public.class_schedules (class_id, weekday, start_time);

-- ---------- updated_at triggers ----------
do $$
declare t text;
begin
  foreach t in array array[
    'departments', 'classes', 'profiles', 'subjects', 'books', 'lessons',
    'resources', 'announcements', 'assignments', 'submissions', 'class_schedules'
  ] loop
    execute format(
      'create trigger set_updated_at before update on public.%I
         for each row execute function public.set_updated_at()', t);
  end loop;
end $$;

-- ---------- New auth user -> profile ----------
-- SECURITY: only app_metadata (settable by the service role, never by the user)
-- may choose "teacher". Everyone else starts as "student". A super admin is
-- created manually (see supabase/README.md). user_metadata is never trusted.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_role public.user_role;
begin
  v_role := case new.raw_app_meta_data ->> 'role'
              when 'teacher' then 'teacher'::public.user_role
              else 'student'::public.user_role
            end;

  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''),
             nullif(split_part(coalesce(new.email, ''), '@', 1), ''),
             'Unnamed'),
    v_role
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
