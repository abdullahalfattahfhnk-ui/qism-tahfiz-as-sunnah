-- =====================================================================
-- قسم تحفيظ السنة (Qism Tahfiz as-Sunnah)
-- Migration 3 of 3: private Storage buckets and their access rules
-- =====================================================================
-- Path conventions (enforced by the policies below):
--   resources   : <class_id>/<file name>
--   submissions : <assignment_id>/<student_id>/<file name>
-- Both buckets are private. Files are served through short-lived signed URLs.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('resources',   'resources',   false, 52428800,
   array['application/pdf', 'audio/mpeg', 'audio/mp4', 'image/jpeg', 'image/png']),
  ('submissions', 'submissions', false, 20971520,
   array['application/pdf', 'audio/mpeg', 'audio/mp4', 'image/jpeg', 'image/png'])
on conflict (id) do update
  set public = false,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- ---------- resources bucket ----------
-- Read: only files whose "resources" row the caller can already see
-- (so students never get unpublished files). Write: teachers of the class, super admin.
create policy "resources_read" on storage.objects
  for select to authenticated
  using (
    bucket_id = 'resources'
    and exists (
      select 1 from public.resources r where r.storage_path = storage.objects.name
    )
  );

create policy "resources_insert" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'resources'
    and (
      public.is_super_admin()
      or public.is_class_teacher(public.safe_uuid((storage.foldername(name))[1]))
    )
  );

create policy "resources_update" on storage.objects
  for update to authenticated
  using (
    bucket_id = 'resources'
    and (
      public.is_super_admin()
      or public.is_class_teacher(public.safe_uuid((storage.foldername(name))[1]))
    )
  );

create policy "resources_delete" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'resources'
    and (
      public.is_super_admin()
      or public.is_class_teacher(public.safe_uuid((storage.foldername(name))[1]))
    )
  );

-- ---------- submissions bucket ----------
-- A student works only inside their own folder, for assignments they may see.
-- Teachers of the class and super admins can read.
create policy "submissions_read" on storage.objects
  for select to authenticated
  using (
    bucket_id = 'submissions'
    and (
      (storage.foldername(name))[2] = (select auth.uid())::text
      or public.is_assignment_teacher(public.safe_uuid((storage.foldername(name))[1]))
      or public.is_super_admin()
    )
  );

create policy "submissions_insert" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'submissions'
    and (storage.foldername(name))[2] = (select auth.uid())::text
    and public.is_assignment_student(public.safe_uuid((storage.foldername(name))[1]))
  );

create policy "submissions_update" on storage.objects
  for update to authenticated
  using (
    bucket_id = 'submissions'
    and (storage.foldername(name))[2] = (select auth.uid())::text
    and public.is_assignment_student(public.safe_uuid((storage.foldername(name))[1]))
  );

create policy "submissions_delete" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'submissions'
    and (storage.foldername(name))[2] = (select auth.uid())::text
    and public.is_assignment_student(public.safe_uuid((storage.foldername(name))[1]))
  );
