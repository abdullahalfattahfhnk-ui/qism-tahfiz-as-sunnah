-- =====================================================================
-- قسم تحفيظ السنة (Qism Tahfiz as-Sunnah)
-- Migration 4: explicit table privileges (matches the RLS policies)
-- =====================================================================
-- Why: Postgres checks GRANTs first, then Row Level Security. Newer Supabase
-- projects do not hand out table privileges automatically, so the signed-in
-- role ("authenticated") needs them stated. RLS then decides WHICH rows.
-- This file is safe to run more than once.
-- =====================================================================

grant usage on schema public to authenticated, service_role;

-- Start from a clean, deterministic state.
revoke all on all tables in schema public from authenticated;
alter default privileges in schema public revoke all on tables from authenticated;

-- The server (service role) manages everything; it bypasses RLS by design.
grant all on all tables in schema public to service_role;
alter default privileges in schema public grant all on tables to service_role;

-- Tables where some policy allows writes (RLS limits who and which rows):
--   * structure and catalog: super admin only
--   * books, lessons, resources, assignments, announcements: teachers of the class, super admin
grant select, insert, update, delete on
  public.departments,
  public.subjects,
  public.classes,
  public.class_members,
  public.class_schedules,
  public.books,
  public.lessons,
  public.resources,
  public.assignments,
  public.announcements
to authenticated;

-- Profiles: read (RLS narrows who). Update only the display columns.
-- Accounts are created/deleted, and role/is_active/student_code changed,
-- only by the server with the service-role key.
grant select on public.profiles to authenticated;
grant update (full_name, preferred_locale, avatar_path) on public.profiles to authenticated;

-- Submissions: students insert/update only these columns (submitted_at cannot
-- be forged). Delete is allowed by RLS for super admin only.
grant select, delete on public.submissions to authenticated;
grant insert (assignment_id, student_id, content, file_path) on public.submissions to authenticated;
grant update (content, file_path) on public.submissions to authenticated;

-- Not signed in (anon): no table privileges at all.
revoke all on all tables in schema public from anon;
