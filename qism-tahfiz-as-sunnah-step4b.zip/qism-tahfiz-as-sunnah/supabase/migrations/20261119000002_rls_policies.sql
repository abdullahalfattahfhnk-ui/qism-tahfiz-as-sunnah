-- =====================================================================
-- قسم تحفيظ السنة (Qism Tahfiz as-Sunnah)
-- Migration 2 of 3: access control (helpers, grants, Row Level Security)
-- =====================================================================
-- Principles
--  * Nobody who is not signed in can read or write anything.
--  * Deny by default: a table with RLS enabled and no matching policy is closed.
--  * Role changes, activation and account creation happen ONLY on the server
--    with the service-role key (it bypasses RLS). Browsers cannot do them.
-- =====================================================================

-- ---------- Helper functions ----------
-- SECURITY DEFINER lets policies check membership without RLS recursion.
-- search_path is pinned, and every helper returns false/null for inactive users.

create or replace function public.app_role()
returns public.user_role
language sql stable security definer set search_path = ''
as $$
  select p.role from public.profiles p
  where p.id = auth.uid() and p.is_active
$$;

create or replace function public.is_super_admin()
returns boolean
language sql stable security definer set search_path = ''
as $$
  select coalesce(public.app_role() = 'super_admin', false)
$$;

-- Member of the class in any capacity (profile role must match membership role).
create or replace function public.is_class_member(p_class uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1
    from public.class_members m
    join public.profiles p on p.id = m.profile_id and p.role = m.member_role and p.is_active
    where m.class_id = p_class and m.profile_id = auth.uid()
  )
$$;

create or replace function public.is_class_teacher(p_class uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1
    from public.class_members m
    join public.profiles p on p.id = m.profile_id and p.role = m.member_role and p.is_active
    where m.class_id = p_class and m.profile_id = auth.uid() and m.member_role = 'teacher'
  )
$$;

create or replace function public.is_class_student(p_class uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1
    from public.class_members m
    join public.profiles p on p.id = m.profile_id and p.role = m.member_role and p.is_active
    where m.class_id = p_class and m.profile_id = auth.uid() and m.member_role = 'student'
  )
$$;

-- The signed-in user is a teacher of the class this assignment belongs to.
create or replace function public.is_assignment_teacher(p_assignment uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.assignments a
    where a.id = p_assignment and public.is_class_teacher(a.class_id)
  )
$$;

-- The signed-in user is a student of the class and the assignment is published.
create or replace function public.is_assignment_student(p_assignment uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.assignments a
    where a.id = p_assignment and a.is_published and public.is_class_student(a.class_id)
  )
$$;

-- Who may read whose profile:
--   * yourself
--   * super admin: everyone
--   * a teacher: everyone in their classes
--   * a member: the teachers of their classes (students cannot see classmates)
--   * everyone: active super admins (shown as the school administration)
create or replace function public.can_view_profile(p_profile uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select public.app_role() is not null and (
    p_profile = auth.uid()
    or public.is_super_admin()
    or exists (
      select 1
      from public.class_members me
      join public.class_members other on other.class_id = me.class_id
      where me.profile_id = auth.uid()
        and other.profile_id = p_profile
        and (me.member_role = 'teacher' or other.member_role = 'teacher')
    )
    or exists (
      select 1 from public.profiles a
      where a.id = p_profile and a.role = 'super_admin' and a.is_active
    )
  )
$$;

-- Used by storage policies: turns text into uuid, or null if malformed.
create or replace function public.safe_uuid(p text)
returns uuid
language plpgsql immutable set search_path = ''
as $$
begin
  return p::uuid;
exception when others then
  return null;
end;
$$;

-- ---------- Lock down grants ----------
-- Anonymous (not signed-in) visitors get nothing.
revoke all on all tables in schema public from anon;
alter default privileges in schema public revoke all on tables from anon;
revoke execute on all functions in schema public from public, anon;
alter default privileges in schema public revoke execute on functions from public, anon;

grant execute on function
  public.app_role(), public.is_super_admin(), public.is_class_member(uuid),
  public.is_class_teacher(uuid), public.is_class_student(uuid),
  public.is_assignment_teacher(uuid), public.is_assignment_student(uuid),
  public.can_view_profile(uuid), public.safe_uuid(text)
to authenticated, service_role;

-- Profiles: signed-in users may only edit their own display fields.
-- role, is_active and student_code can be changed only by the server (service role).
revoke insert, update, delete on public.profiles from authenticated;
grant update (full_name, preferred_locale, avatar_path) on public.profiles to authenticated;

-- Submissions: students may set only these columns (submitted_at cannot be forged).
revoke insert, update on public.submissions from authenticated;
grant insert (assignment_id, student_id, content, file_path) on public.submissions to authenticated;
grant update (content, file_path) on public.submissions to authenticated;

-- ---------- Enable RLS everywhere ----------
alter table public.departments     enable row level security;
alter table public.classes         enable row level security;
alter table public.profiles        enable row level security;
alter table public.class_members   enable row level security;
alter table public.subjects        enable row level security;
alter table public.books           enable row level security;
alter table public.lessons         enable row level security;
alter table public.resources       enable row level security;
alter table public.announcements   enable row level security;
alter table public.assignments     enable row level security;
alter table public.submissions     enable row level security;
alter table public.class_schedules enable row level security;

-- ---------- profiles ----------
create policy profiles_select on public.profiles
  for select to authenticated
  using (public.can_view_profile(id));

create policy profiles_update_own on public.profiles
  for update to authenticated
  using (id = (select auth.uid()) and is_active)
  with check (id = (select auth.uid()));

create policy profiles_update_admin on public.profiles
  for update to authenticated
  using (public.is_super_admin())
  with check (public.is_super_admin());
-- No INSERT/DELETE policy: accounts are created and removed by the server only.

-- ---------- departments, subjects (catalog) ----------
create policy departments_select on public.departments
  for select to authenticated using (public.app_role() is not null);
create policy departments_admin on public.departments
  for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());

create policy subjects_select on public.subjects
  for select to authenticated using (public.app_role() is not null);
create policy subjects_admin on public.subjects
  for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());

-- ---------- classes, class_members, class_schedules ----------
create policy classes_select on public.classes
  for select to authenticated
  using (public.is_super_admin() or public.is_class_member(id));
create policy classes_admin on public.classes
  for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());

create policy class_members_select on public.class_members
  for select to authenticated
  using (
    profile_id = (select auth.uid())
    or public.is_class_teacher(class_id)
    or public.is_super_admin()
  );
create policy class_members_admin on public.class_members
  for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());

create policy class_schedules_select on public.class_schedules
  for select to authenticated
  using (public.is_super_admin() or public.is_class_member(class_id));
create policy class_schedules_admin on public.class_schedules
  for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());

-- ---------- books, lessons, resources, assignments ----------
-- Same rule for all four tables:
--   read   : super admin, teachers of the class (drafts too), students of the class (published only)
--   write  : super admin, teachers of the class
do $$
declare t text;
begin
  foreach t in array array['books', 'lessons', 'resources', 'assignments'] loop
    execute format($f$
      create policy %1$I on public.%2$I for select to authenticated
      using (
        public.is_super_admin()
        or public.is_class_teacher(class_id)
        or (is_published and public.is_class_student(class_id))
      )$f$, t || '_select', t);

    execute format($f$
      create policy %1$I on public.%2$I for insert to authenticated
      with check (
        (public.is_super_admin() or public.is_class_teacher(class_id))
        and created_by = (select auth.uid())
      )$f$, t || '_insert', t);

    execute format($f$
      create policy %1$I on public.%2$I for update to authenticated
      using (public.is_super_admin() or public.is_class_teacher(class_id))
      with check (public.is_super_admin() or public.is_class_teacher(class_id))$f$,
      t || '_update', t);

    execute format($f$
      create policy %1$I on public.%2$I for delete to authenticated
      using (public.is_super_admin() or public.is_class_teacher(class_id))$f$,
      t || '_delete', t);
  end loop;
end $$;

-- ---------- announcements ----------
-- class_id null = madrasa-wide: readable by every active user, writable by super admin only.
create policy announcements_select on public.announcements
  for select to authenticated
  using (
    public.is_super_admin()
    or (class_id is not null and public.is_class_teacher(class_id))
    or (
      is_published and published_at <= now() and (
        (class_id is null and public.app_role() is not null)
        or (class_id is not null and public.is_class_member(class_id))
      )
    )
  );

create policy announcements_insert on public.announcements
  for insert to authenticated
  with check (
    (public.is_super_admin() or (class_id is not null and public.is_class_teacher(class_id)))
    and created_by = (select auth.uid())
  );

create policy announcements_update on public.announcements
  for update to authenticated
  using (public.is_super_admin() or (class_id is not null and public.is_class_teacher(class_id)))
  with check (public.is_super_admin() or (class_id is not null and public.is_class_teacher(class_id)));

create policy announcements_delete on public.announcements
  for delete to authenticated
  using (public.is_super_admin() or (class_id is not null and public.is_class_teacher(class_id)));

-- ---------- submissions ----------
create policy submissions_select on public.submissions
  for select to authenticated
  using (
    student_id = (select auth.uid())
    or public.is_assignment_teacher(assignment_id)
    or public.is_super_admin()
  );

create policy submissions_insert on public.submissions
  for insert to authenticated
  with check (
    student_id = (select auth.uid())
    and public.is_assignment_student(assignment_id)
  );

create policy submissions_update on public.submissions
  for update to authenticated
  using (student_id = (select auth.uid()) and public.is_assignment_student(assignment_id))
  with check (student_id = (select auth.uid()) and public.is_assignment_student(assignment_id));

create policy submissions_delete on public.submissions
  for delete to authenticated
  using (public.is_super_admin());
