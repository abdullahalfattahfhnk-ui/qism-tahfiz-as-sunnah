# Supabase setup: قسم تحفيظ السنة (Qism Tahfiz as-Sunnah)

## 1. Create the project and turn off public sign-up
1. Create a project at supabase.com.
2. Authentication -> Sign In / Providers -> **turn OFF "Allow new users to sign up"**.
   (Required: there is no public registration. Accounts are created by a Super Admin only.)

## 2. Run the SQL (Supabase dashboard -> SQL Editor), in this order
1. `migrations/20261119000001_core_schema.sql`
2. `migrations/20261119000002_rls_policies.sql`
3. `migrations/20261119000003_storage.sql`
3b. `migrations/20261119000004_table_grants.sql` (table privileges; required on newer Supabase projects)
4. `seed.sql` (optional: one department, one class, five subjects. Edit names first if you like.)
5. `tests/rls_smoke_test.sql` (recommended: checks the access rules, then rolls back)

## 3. Create the first Super Admin
1. Authentication -> Users -> **Add user** -> create with email and password (tick "Auto confirm").
2. SQL Editor, using that user's email:
   ```sql
   update public.profiles
   set role = 'super_admin', full_name = 'Your name'
   where id = (select id from auth.users where email = 'you@example.com');
   ```

## Who can do what
| Data | Super admin | Teacher | Student |
|---|---|---|---|
| Profiles | all (edit display fields; role changes via server) | self + people in own classes | self + own teachers + administration |
| Departments, subjects | read, write | read | read |
| Classes, members, schedules | read, write | read own classes | read own classes |
| Books, lessons, resources | all | own classes, incl. drafts; write | own class, published only |
| Announcements | all (incl. madrasa-wide) | own classes; write | madrasa-wide + own class, published |
| Assignments | all | own classes; write | own class, published only |
| Submissions | read all | read for own classes | create/edit own only |
| Files (Storage) | all | upload to own classes | read published files; upload own submissions |

## Things that happen on the server only (service-role key)
Creating users, changing `role` / `is_active` / `student_code`, and adding class
members. The service-role key must never be used in browser code or committed to git.
These server actions are built in the next step.

## Known limits (by design, for now)
- Deleting a class is blocked while it has content (prevents accidental loss).
- Deleting a resource row does not delete its Storage file; cleanup is added with uploads.
- Grades, attendance and exams are not modelled yet; the schema leaves room for them.
