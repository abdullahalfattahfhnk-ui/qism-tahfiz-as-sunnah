-- =====================================================================
-- Optional starter data. Safe to run more than once.
-- Edit the names to match your madrasa. Contains NO users and NO secrets.
-- =====================================================================

insert into public.departments (code, name_ar, name_en)
values ('main', 'قسم تحفيظ السنة', 'Qism Tahfiz as-Sunnah')
on conflict (code) do nothing;

insert into public.classes (department_id, name_ar, name_bn, name_en, academic_year)
select d.id, 'الصف الأول', 'প্রথম ক্লাস', 'Class 1', '2026-2027'
from public.departments d
where d.code = 'main'
  and not exists (
    select 1 from public.classes c where c.department_id = d.id and c.name_en = 'Class 1'
  );

insert into public.subjects (department_id, code, name_ar, name_bn, name_en)
select d.id, s.code, s.name_ar, s.name_bn, s.name_en
from public.departments d
cross join (values
  ('hadith',  'حفظ الأحاديث', 'হাদিস মুখস্থ',  'Hadith memorization'),
  ('arabic',  'النحو',        'আরবি ব্যাকরণ',   'Arabic grammar'),
  ('fiqh',    'الفقه',        'ফিকহ',          'Fiqh'),
  ('sirah',   'السيرة',       'সীরাত',         'Sirah'),
  ('tajweed', 'التجويد',      'তাজবীদ',        'Tajweed')
) as s (code, name_ar, name_bn, name_en)
where d.code = 'main'
on conflict (department_id, code) do nothing;
