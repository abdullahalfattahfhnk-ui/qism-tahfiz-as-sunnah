-- =====================================================================
-- قسم تحفيظ السنة (Qism Tahfiz as-Sunnah)
-- ALL-IN-ONE SETUP: reset + schema + RLS + storage + seed, in one paste.
-- WARNING: Part 0 deletes all data in the app's tables (not auth users).
-- Use it only on a fresh or test project.
-- =====================================================================

-- ---------- Part 0: reset (safe if nothing exists yet) ----------
drop trigger if exists on_auth_user_created on auth.users;

drop policy if exists "resources_read"      on storage.objects;
drop policy if exists "resources_insert"    on storage.objects;
drop policy if exists "resources_update"    on storage.objects;
drop policy if exists "resources_delete"    on storage.objects;
drop policy if exists "submissions_read"    on storage.objects;
drop policy if exists "submissions_insert"  on storage.objects;
drop policy if exists "submissions_update"  on storage.objects;
drop policy if exists "submissions_delete"  on storage.objects;

drop table if exists public.submissions, public.class_schedules,
  public.assignments, public.announcements, public.resources,
  public.lessons, public.books, public.subjects, public.class_members,
  public.profiles, public.classes, public.departments cascade;

drop function if exists public.handle_new_user();
drop function if exists public.set_updated_at();
drop type if exists public.announcement_category;
drop type if exists public.resource_type;
drop type if exists public.user_role cascade;


-- ---------- migrations/20261119000001_core_schema.sql ----------
-- =====================================================================
-- قسم تحفيظ السنة (Qism Tahfiz as-Sunnah)
-- Migration 1 of 3: core schema (types, tables, indexes, triggers)
-- Run order: 1 schema -> 2 rls -> 3 storage
-- =====================================================================

-- ---------- Types ----------
create type public.user_role as enum ('super_admin', 'teacher', 'student');
create type public.resource_type as enum ('book', 'notes', 'audio', 'worksheet');
create type public.announcement_category as enum ('general', 'academic', 'event');

-- ---------- Shared trigger: keep updated_at current ----------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ---------- Structure: departments, classes ----------
create table public.departments (
  id          uuid primary key default gen_random_uuid(),
  code        text not null unique,
  name_ar     text,
  name_bn     text,
  name_en     text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  constraint departments_has_name check (coalesce(name_ar, name_bn, name_en) is not null)
);

create table public.classes (
  id            uuid primary key default gen_random_uuid(),
  department_id uuid not null references public.departments (id) on delete restrict,
  name_ar       text,
  name_bn       text,
  name_en       text,
  academic_year text,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  constraint classes_has_name check (coalesce(name_ar, name_bn, name_en) is not null)
);
create index classes_department_idx on public.classes (department_id);

-- ---------- People ----------
-- One row per auth user. Email and password live in auth.users only.
create table public.profiles (
  id               uuid primary key references auth.users (id) on delete cascade,
  full_name        text not null check (length(trim(full_name)) > 0),
  role             public.user_role not null default 'student',
  student_code     text unique,
  preferred_locale text not null default 'bn' check (preferred_locale in ('bn', 'ar', 'en')),
  avatar_path      text,
  is_active        boolean not null default true,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

-- Who belongs to which class, and in what capacity.
-- Teachers can belong to many classes; students normally to one.
create table public.class_members (
  class_id    uuid not null references public.classes (id) on delete cascade,
  profile_id  uuid not null references public.profiles (id) on delete cascade,
  member_role public.user_role not null check (member_role in ('teacher', 'student')),
  created_at  timestamptz not null default now(),
  primary key (class_id, profile_id)
);
create index class_members_profile_idx on public.class_members (profile_id);

-- ---------- Academic content ----------
create table public.subjects (
  id            uuid primary key default gen_random_uuid(),
  department_id uuid not null references public.departments (id) on delete restrict,
  code          text not null,
  name_ar       text,
  name_bn       text,
  name_en       text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (department_id, code),
  constraint subjects_has_name check (coalesce(name_ar, name_bn, name_en) is not null)
);

create table public.books (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid not null references public.classes (id) on delete restrict,
  subject_id   uuid references public.subjects (id) on delete set null,
  title        text not null,
  author       text,
  description  text,
  is_published boolean not null default false,
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index books_class_idx on public.books (class_id, subject_id);

create table public.lessons (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid not null references public.classes (id) on delete restrict,
  subject_id   uuid references public.subjects (id) on delete set null,
  book_id      uuid references public.books (id) on delete set null,
  title        text not null,
  summary      text,
  position     integer not null default 0,
  is_published boolean not null default false,
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index lessons_class_idx on public.lessons (class_id, subject_id, position);

-- A file in Storage (bucket "resources"), described by a row here.
create table public.resources (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid not null references public.classes (id) on delete restrict,
  subject_id   uuid references public.subjects (id) on delete set null,
  lesson_id    uuid references public.lessons (id) on delete set null,
  book_id      uuid references public.books (id) on delete set null,
  type         public.resource_type not null,
  title        text not null,
  description  text,
  storage_path text not null unique,   -- "<class_id>/<file>" inside bucket "resources"
  file_name    text,
  mime_type    text,
  size_bytes   bigint check (size_bytes >= 0),
  is_published boolean not null default false,
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index resources_class_idx on public.resources (class_id, subject_id);

-- ---------- Communication ----------
-- class_id null = madrasa-wide announcement (super admin only).
create table public.announcements (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid references public.classes (id) on delete restrict,
  category     public.announcement_category not null default 'general',
  title        text not null,
  body         text not null,
  is_pinned    boolean not null default false,
  is_published boolean not null default true,
  published_at timestamptz not null default now(),
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index announcements_class_idx on public.announcements (class_id, published_at desc);

-- ---------- Assignments ----------
create table public.assignments (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid not null references public.classes (id) on delete restrict,
  subject_id   uuid references public.subjects (id) on delete set null,
  title        text not null,
  description  text,
  due_at       timestamptz,
  is_published boolean not null default false,
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index assignments_class_idx on public.assignments (class_id, due_at);

-- One submission per student per assignment. Grades come later (exams/results).
create table public.submissions (
  id            uuid primary key default gen_random_uuid(),
  assignment_id uuid not null references public.assignments (id) on delete cascade,
  student_id    uuid not null references public.profiles (id) on delete cascade,
  content       text,
  file_path     text,   -- "<assignment_id>/<student_id>/<file>" inside bucket "submissions"
  submitted_at  timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (assignment_id, student_id),
  constraint submissions_has_content check (content is not null or file_path is not null)
);
create index submissions_student_idx on public.submissions (student_id);

-- ---------- Timetable ----------
create table public.class_schedules (
  id         uuid primary key default gen_random_uuid(),
  class_id   uuid not null references public.classes (id) on delete restrict,
  subject_id uuid references public.subjects (id) on delete set null,
  teacher_id uuid references public.profiles (id) on delete set null,
  weekday    smallint not null check (weekday between 0 and 6),  -- 0 = Sunday ... 6 = Saturday
  start_time time not null,
  end_time   time not null,
  room       text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint class_schedules_time_order check (end_time > start_time)
);
create index class_schedules_class_idx on public.class_schedules (class_id, weekday, start_time);

-- ---------- updated_at triggers ----------
do $$
declare t text;
begin
  foreach t in array array[
    'departments', 'classes', 'profiles', 'subjects', 'books', 'lessons',
    'resources', 'announcements', 'assignments', 'submissions', 'class_schedules'
  ] loop
    execute format(
      'create trigger set_updated_at before update on public.%I
         for each row execute function public.set_updated_at()', t);
  end loop;
end $$;

-- ---------- New auth user -> profile ----------
-- SECURITY: only app_metadata (settable by the service role, never by the user)
-- may choose "teacher". Everyone else starts as "student". A super admin is
-- created manually (see supabase/README.md). user_metadata is never trusted.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_role public.user_role;
begin
  v_role := case new.raw_app_meta_data ->> 'role'
              when 'teacher' then 'teacher'::public.user_role
              else 'student'::public.user_role
            end;

  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''),
             nullif(split_part(coalesce(new.email, ''), '@', 1), ''),
             'Unnamed'),
    v_role
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- migrations/20261119000002_rls_policies.sql ----------
-- =====================================================================
-- قسم تحفيظ السنة (Qism Tahfiz as-Sunnah)
-- Migration 2 of 3: access control (helpers, grants, Row Level Security)
-- =====================================================================
-- Principles
--  * Nobody who is not signed in can read or write anything.
--  * Deny by default: a table with RLS enabled and no matching policy is closed.
--  * Role changes, activation and account creation happen ONLY on the server
--    with the service-role key (it bypasses RLS). Browsers cannot do them.
-- =====================================================================

-- ---------- Helper functions ----------
-- SECURITY DEFINER lets policies check membership without RLS recursion.
-- search_path is pinned, and every helper returns false/null for inactive users.

create or replace function public.app_role()
returns public.user_role
language sql stable security definer set search_path = ''
as $$
  select p.role from public.profiles p
  where p.id = auth.uid() and p.is_active
$$;

create or replace function public.is_super_admin()
returns boolean
language sql stable security definer set search_path = ''
as $$
  select coalesce(public.app_role() = 'super_admin', false)
$$;

-- Member of the class in any capacity (profile role must match membership role).
create or replace function public.is_class_member(p_class uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1
    from public.class_members m
    join public.profiles p on p.id = m.profile_id and p.role = m.member_role and p.is_active
    where m.class_id = p_class and m.profile_id = auth.uid()
  )
$$;

create or replace function public.is_class_teacher(p_class uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1
    from public.class_members m
    join public.profiles p on p.id = m.profile_id and p.role = m.member_role and p.is_active
    where m.class_id = p_class and m.profile_id = auth.uid() and m.member_role = 'teacher'
  )
$$;

create or replace function public.is_class_student(p_class uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1
    from public.class_members m
    join public.profiles p on p.id = m.profile_id and p.role = m.member_role and p.is_active
    where m.class_id = p_class and m.profile_id = auth.uid() and m.member_role = 'student'
  )
$$;

-- The signed-in user is a teacher of the class this assignment belongs to.
create or replace function public.is_assignment_teacher(p_assignment uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.assignments a
    where a.id = p_assignment and public.is_class_teacher(a.class_id)
  )
$$;

-- The signed-in user is a student of the class and the assignment is published.
create or replace function public.is_assignment_student(p_assignment uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.assignments a
    where a.id = p_assignment and a.is_published and public.is_class_student(a.class_id)
  )
$$;

-- Who may read whose profile:
--   * yourself
--   * super admin: everyone
--   * a teacher: everyone in their classes
--   * a member: the teachers of their classes (students cannot see classmates)
--   * everyone: active super admins (shown as the school administration)
create or replace function public.can_view_profile(p_profile uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select public.app_role() is not null and (
    p_profile = auth.uid()
    or public.is_super_admin()
    or exists (
      select 1
      from public.class_members me
      join public.class_members other on other.class_id = me.class_id
      where me.profile_id = auth.uid()
        and other.profile_id = p_profile
        and (me.member_role = 'teacher' or other.member_role = 'teacher')
    )
    or exists (
      select 1 from public.profiles a
      where a.id = p_profile and a.role = 'super_admin' and a.is_active
    )
  )
$$;

-- Used by storage policies: turns text into uuid, or null if malformed.
create or replace function public.safe_uuid(p text)
returns uuid
language plpgsql immutable set search_path = ''
as $$
begin
  return p::uuid;
exception when others then
  return null;
end;
$$;

-- ---------- Lock down grants ----------
-- Anonymous (not signed-in) visitors get nothing.
revoke all on all tables in schema public from anon;
alter default privileges in schema public revoke all on tables from anon;
revoke execute on all functions in schema public from public, anon;
alter default privileges in schema public revoke execute on functions from public, anon;

grant execute on function
  public.app_role(), public.is_super_admin(), public.is_class_member(uuid),
  public.is_class_teacher(uuid), public.is_class_student(uuid),
  public.is_assignment_teacher(uuid), public.is_assignment_student(uuid),
  public.can_view_profile(uuid), public.safe_uuid(text)
to authenticated, service_role;

-- Profiles: signed-in users may only edit their own display fields.
-- role, is_active and student_code can be changed only by the server (service role).
revoke insert, update, delete on public.profiles from authenticated;
grant update (full_name, preferred_locale, avatar_path) on public.profiles to authenticated;

-- Submissions: students may set only these columns (submitted_at cannot be forged).
revoke insert, update on public.submissions from authenticated;
grant insert (assignment_id, student_id, content, file_path) on public.submissions to authenticated;
grant update (content, file_path) on public.submissions to authenticated;

-- ---------- Enable RLS everywhere ----------
alter table public.departments     enable row level security;
alter table public.classes         enable row level security;
alter table public.profiles        enable row level security;
alter table public.class_members   enable row level security;
alter table public.subjects        enable row level security;
alter table public.books           enable row level security;
alter table public.lessons         enable row level security;
alter table public.resources       enable row level security;
alter table public.announcements   enable row level security;
alter table public.assignments     enable row level security;
alter table public.submissions     enable row level security;
alter table public.class_schedules enable row level security;

-- ---------- profiles ----------
create policy profiles_select on public.profiles
  for select to authenticated
  using (public.can_view_profile(id));

create policy profiles_update_own on public.profiles
  for update to authenticated
  using (id = (select auth.uid()) and is_active)
  with check (id = (select auth.uid()));

create policy profiles_update_admin on public.profiles
  for update to authenticated
  using (public.is_super_admin())
  with check (public.is_super_admin());
-- No INSERT/DELETE policy: accounts are created and removed by the server only.

-- ---------- departments, subjects (catalog) ----------
create policy departments_select on public.departments
  for select to authenticated using (public.app_role() is not null);
create policy departments_admin on public.departments
  for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());

create policy subjects_select on public.subjects
  for select to authenticated using (public.app_role() is not null);
create policy subjects_admin on public.subjects
  for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());

-- ---------- classes, class_members, class_schedules ----------
create policy classes_select on public.classes
  for select to authenticated
  using (public.is_super_admin() or public.is_class_member(id));
create policy classes_admin on public.classes
  for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());

create policy class_members_select on public.class_members
  for select to authenticated
  using (
    profile_id = (select auth.uid())
    or public.is_class_teacher(class_id)
    or public.is_super_admin()
  );
create policy class_members_admin on public.class_members
  for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());

create policy class_schedules_select on public.class_schedules
  for select to authenticated
  using (public.is_super_admin() or public.is_class_member(class_id));
create policy class_schedules_admin on public.class_schedules
  for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());

-- ---------- books, lessons, resources, assignments ----------
-- Same rule for all four tables:
--   read   : super admin, teachers of the class (drafts too), students of the class (published only)
--   write  : super admin, teachers of the class
do $$
declare t text;
begin
  foreach t in array array['books', 'lessons', 'resources', 'assignments'] loop
    execute format($f$
      create policy %1$I on public.%2$I for select to authenticated
      using (
        public.is_super_admin()
        or public.is_class_teacher(class_id)
        or (is_published and public.is_class_student(class_id))
      )$f$, t || '_select', t);

    execute format($f$
      create policy %1$I on public.%2$I for insert to authenticated
      with check (
        (public.is_super_admin() or public.is_class_teacher(class_id))
        and created_by = (select auth.uid())
      )$f$, t || '_insert', t);

    execute format($f$
      create policy %1$I on public.%2$I for update to authenticated
      using (public.is_super_admin() or public.is_class_teacher(class_id))
      with check (public.is_super_admin() or public.is_class_teacher(class_id))$f$,
      t || '_update', t);

    execute format($f$
      create policy %1$I on public.%2$I for delete to authenticated
      using (public.is_super_admin() or public.is_class_teacher(class_id))$f$,
      t || '_delete', t);
  end loop;
end $$;

-- ---------- announcements ----------
-- class_id null = madrasa-wide: readable by every active user, writable by super admin only.
create policy announcements_select on public.announcements
  for select to authenticated
  using (
    public.is_super_admin()
    or (class_id is not null and public.is_class_teacher(class_id))
    or (
      is_published and published_at <= now() and (
        (class_id is null and public.app_role() is not null)
        or (class_id is not null and public.is_class_member(class_id))
      )
    )
  );

create policy announcements_insert on public.announcements
  for insert to authenticated
  with check (
    (public.is_super_admin() or (class_id is not null and public.is_class_teacher(class_id)))
    and created_by = (select auth.uid())
  );

create policy announcements_update on public.announcements
  for update to authenticated
  using (public.is_super_admin() or (class_id is not null and public.is_class_teacher(class_id)))
  with check (public.is_super_admin() or (class_id is not null and public.is_class_teacher(class_id)));

create policy announcements_delete on public.announcements
  for delete to authenticated
  using (public.is_super_admin() or (class_id is not null and public.is_class_teacher(class_id)));

-- ---------- submissions ----------
create policy submissions_select on public.submissions
  for select to authenticated
  using (
    student_id = (select auth.uid())
    or public.is_assignment_teacher(assignment_id)
    or public.is_super_admin()
  );

create policy submissions_insert on public.submissions
  for insert to authenticated
  with check (
    student_id = (select auth.uid())
    and public.is_assignment_student(assignment_id)
  );

create policy submissions_update on public.submissions
  for update to authenticated
  using (student_id = (select auth.uid()) and public.is_assignment_student(assignment_id))
  with check (student_id = (select auth.uid()) and public.is_assignment_student(assignment_id));

create policy submissions_delete on public.submissions
  for delete to authenticated
  using (public.is_super_admin());

-- ---------- migrations/20261119000003_storage.sql ----------
-- =====================================================================
-- قسم تحفيظ السنة (Qism Tahfiz as-Sunnah)
-- Migration 3 of 3: private Storage buckets and their access rules
-- =====================================================================
-- Path conventions (enforced by the policies below):
--   resources   : <class_id>/<file name>
--   submissions : <assignment_id>/<student_id>/<file name>
-- Both buckets are private. Files are served through short-lived signed URLs.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('resources',   'resources',   false, 52428800,
   array['application/pdf', 'audio/mpeg', 'audio/mp4', 'image/jpeg', 'image/png']),
  ('submissions', 'submissions', false, 20971520,
   array['application/pdf', 'audio/mpeg', 'audio/mp4', 'image/jpeg', 'image/png'])
on conflict (id) do update
  set public = false,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- ---------- resources bucket ----------
-- Read: only files whose "resources" row the caller can already see
-- (so students never get unpublished files). Write: teachers of the class, super admin.
create policy "resources_read" on storage.objects
  for select to authenticated
  using (
    bucket_id = 'resources'
    and exists (
      select 1 from public.resources r where r.storage_path = storage.objects.name
    )
  );

create policy "resources_insert" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'resources'
    and (
      public.is_super_admin()
      or public.is_class_teacher(public.safe_uuid((storage.foldername(name))[1]))
    )
  );

create policy "resources_update" on storage.objects
  for update to authenticated
  using (
    bucket_id = 'resources'
    and (
      public.is_super_admin()
      or public.is_class_teacher(public.safe_uuid((storage.foldername(name))[1]))
    )
  );

create policy "resources_delete" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'resources'
    and (
      public.is_super_admin()
      or public.is_class_teacher(public.safe_uuid((storage.foldername(name))[1]))
    )
  );

-- ---------- submissions bucket ----------
-- A student works only inside their own folder, for assignments they may see.
-- Teachers of the class and super admins can read.
create policy "submissions_read" on storage.objects
  for select to authenticated
  using (
    bucket_id = 'submissions'
    and (
      (storage.foldername(name))[2] = (select auth.uid())::text
      or public.is_assignment_teacher(public.safe_uuid((storage.foldername(name))[1]))
      or public.is_super_admin()
    )
  );

create policy "submissions_insert" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'submissions'
    and (storage.foldername(name))[2] = (select auth.uid())::text
    and public.is_assignment_student(public.safe_uuid((storage.foldername(name))[1]))
  );

create policy "submissions_update" on storage.objects
  for update to authenticated
  using (
    bucket_id = 'submissions'
    and (storage.foldername(name))[2] = (select auth.uid())::text
    and public.is_assignment_student(public.safe_uuid((storage.foldername(name))[1]))
  );

create policy "submissions_delete" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'submissions'
    and (storage.foldername(name))[2] = (select auth.uid())::text
    and public.is_assignment_student(public.safe_uuid((storage.foldername(name))[1]))
  );

-- ---------- migrations/20261119000004_table_grants.sql ----------
-- =====================================================================
-- قسم تحفيظ السنة (Qism Tahfiz as-Sunnah)
-- Migration 4: explicit table privileges (matches the RLS policies)
-- =====================================================================
-- Why: Postgres checks GRANTs first, then Row Level Security. Newer Supabase
-- projects do not hand out table privileges automatically, so the signed-in
-- role ("authenticated") needs them stated. RLS then decides WHICH rows.
-- This file is safe to run more than once.
-- =====================================================================

grant usage on schema public to authenticated, service_role;

-- Start from a clean, deterministic state.
revoke all on all tables in schema public from authenticated;
alter default privileges in schema public revoke all on tables from authenticated;

-- The server (service role) manages everything; it bypasses RLS by design.
grant all on all tables in schema public to service_role;
alter default privileges in schema public grant all on tables to service_role;

-- Tables where some policy allows writes (RLS limits who and which rows):
--   * structure and catalog: super admin only
--   * books, lessons, resources, assignments, announcements: teachers of the class, super admin
grant select, insert, update, delete on
  public.departments,
  public.subjects,
  public.classes,
  public.class_members,
  public.class_schedules,
  public.books,
  public.lessons,
  public.resources,
  public.assignments,
  public.announcements
to authenticated;

-- Profiles: read (RLS narrows who). Update only the display columns.
-- Accounts are created/deleted, and role/is_active/student_code changed,
-- only by the server with the service-role key.
grant select on public.profiles to authenticated;
grant update (full_name, preferred_locale, avatar_path) on public.profiles to authenticated;

-- Submissions: students insert/update only these columns (submitted_at cannot
-- be forged). Delete is allowed by RLS for super admin only.
grant select, delete on public.submissions to authenticated;
grant insert (assignment_id, student_id, content, file_path) on public.submissions to authenticated;
grant update (content, file_path) on public.submissions to authenticated;

-- Not signed in (anon): no table privileges at all.
revoke all on all tables in schema public from anon;

-- ---------- seed.sql ----------
-- =====================================================================
-- Optional starter data. Safe to run more than once.
-- Edit the names to match your madrasa. Contains NO users and NO secrets.
-- =====================================================================

insert into public.departments (code, name_ar, name_en)
values ('main', 'قسم تحفيظ السنة', 'Qism Tahfiz as-Sunnah')
on conflict (code) do nothing;

insert into public.classes (department_id, name_ar, name_bn, name_en, academic_year)
select d.id, 'الصف الأول', 'প্রথম ক্লাস', 'Class 1', '2026-2027'
from public.departments d
where d.code = 'main'
  and not exists (
    select 1 from public.classes c where c.department_id = d.id and c.name_en = 'Class 1'
  );

insert into public.subjects (department_id, code, name_ar, name_bn, name_en)
select d.id, s.code, s.name_ar, s.name_bn, s.name_en
from public.departments d
cross join (values
  ('hadith',  'حفظ الأحاديث', 'হাদিস মুখস্থ',  'Hadith memorization'),
  ('arabic',  'النحو',        'আরবি ব্যাকরণ',   'Arabic grammar'),
  ('fiqh',    'الفقه',        'ফিকহ',          'Fiqh'),
  ('sirah',   'السيرة',       'সীরাত',         'Sirah'),
  ('tajweed', 'التجويد',      'তাজবীদ',        'Tajweed')
) as s (code, name_ar, name_bn, name_en)
where d.code = 'main'
on conflict (department_id, code) do nothing;

-- ---------- Final: create profiles for users that already exist ----------
-- (needed after the reset, because existing auth users lost their profile rows)
insert into public.profiles (id, full_name)
select u.id, coalesce(nullif(split_part(coalesce(u.email, ''), '@', 1), ''), 'Unnamed')
from auth.users u
on conflict (id) do nothing;

select 'setup complete' as result;
